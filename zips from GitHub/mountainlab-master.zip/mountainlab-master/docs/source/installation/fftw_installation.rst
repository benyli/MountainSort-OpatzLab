FFTW installation
=================

FFTW is only needed for the bandpass filter processor for the mountainsort plugin packages. If you are on Ubuntu, you can do the following prior to compilation:

.. code :: bash
	
	sudo apt-get install libfftw3-dev

Otherwise, visit the `FFTW home page <http://www.fftw.org/>`_

