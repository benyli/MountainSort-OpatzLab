function writemda32ui(X,fname)
writemda(X,fname,'uint32');
end