function mountainlab_setup

mfile_path=fileparts(mfilename('fullpath'));
addpath(mfile_path);
addpath([mfile_path,'/mdaio']);
addpath([mfile_path,'/wrap']);

