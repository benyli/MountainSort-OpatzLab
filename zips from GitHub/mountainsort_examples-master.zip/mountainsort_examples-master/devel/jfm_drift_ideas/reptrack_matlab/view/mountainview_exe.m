function fname=mountainview_exe
mfile_path=fileparts(mfilename('fullpath'));
fname=[mfile_path,'/../../bin/mountainview'];
end