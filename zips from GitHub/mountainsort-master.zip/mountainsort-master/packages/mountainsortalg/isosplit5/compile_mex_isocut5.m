mex ./_mcwrap/mcwrap_isocut5_mex.cpp ./isocut5.cpp ./jisotonic5.cpp -output ./isocut5_mex 
